-- Full replacement migration for commercial model (plan_nueva_bd_dev.md).
-- This migration is destructive by design for {{SCHEMA}} app objects:
-- drops legacy tables/functions/types and recreates the full model.

create schema if not exists {{SCHEMA}};
create extension if not exists pgcrypto;

-- ------------------------------------------------------------
-- Cleanup: functions, tables, and enum types from previous model
-- ------------------------------------------------------------
drop function if exists {{SCHEMA}}.trg_ventas_sync_business_rules() cascade;
drop function if exists {{SCHEMA}}.trg_ventas_insert_titular() cascade;
drop function if exists {{SCHEMA}}.trg_ventas_set_financial_snapshot() cascade;
drop function if exists {{SCHEMA}}.trg_pagos_recalculate_venta_totales() cascade;
drop function if exists {{SCHEMA}}.refresh_lote_estado_comercial(uuid) cascade;
drop function if exists {{SCHEMA}}.recalculate_venta_totales(uuid) cascade;
drop function if exists {{SCHEMA}}.sp_actualizar_precios_disponibles(text, numeric) cascade;
drop function if exists {{SCHEMA}}.set_updated_at() cascade;

drop table if exists {{SCHEMA}}.autorizaciones_admin cascade;
drop table if exists {{SCHEMA}}.pagos cascade;
drop table if exists {{SCHEMA}}.ventas_clientes cascade;
drop table if exists {{SCHEMA}}.ventas cascade;
drop table if exists {{SCHEMA}}.lotes cascade;
drop table if exists {{SCHEMA}}.proyectos cascade;
drop table if exists {{SCHEMA}}.empresas cascade;
drop table if exists {{SCHEMA}}.usuarios cascade;
drop table if exists {{SCHEMA}}.personas cascade;

drop type if exists {{SCHEMA}}.accion_admin_enum cascade;
drop type if exists {{SCHEMA}}.rol_en_venta_enum cascade;
drop type if exists {{SCHEMA}}.forma_pago_enum cascade;
drop type if exists {{SCHEMA}}.tipo_pago_enum cascade;
drop type if exists {{SCHEMA}}.estado_registro_enum cascade;
drop type if exists {{SCHEMA}}.etapa_venta_enum cascade;
drop type if exists {{SCHEMA}}.estado_lote_enum cascade;
drop type if exists {{SCHEMA}}.tipo_documento_enum cascade;
drop type if exists {{SCHEMA}}.estado_general_enum cascade;
drop type if exists {{SCHEMA}}.rol_usuario_enum cascade;

-- ------------------------------------------------------------
-- Enums
-- ------------------------------------------------------------
create type {{SCHEMA}}.rol_usuario_enum as enum ('ADMIN', 'ASESOR', 'CLIENTE', 'SUPERVISOR');
create type {{SCHEMA}}.estado_general_enum as enum ('ACTIVO', 'INACTIVO');
create type {{SCHEMA}}.tipo_documento_enum as enum ('DNI', 'CE', 'PASAPORTE', 'RUC', 'OTRO');
create type {{SCHEMA}}.estado_lote_enum as enum ('LIBRE', 'SEPARADO', 'VENDIDO', 'BLOQUEADO', 'INACTIVO');
create type {{SCHEMA}}.etapa_venta_enum as enum ('SEPARADO', 'CONTRATO', 'PAGANDO', 'COMPLETADO', 'ANULADO');
create type {{SCHEMA}}.estado_registro_enum as enum ('ACTIVO', 'ANULADO', 'ELIMINADO_LOGICO');
create type {{SCHEMA}}.tipo_pago_enum as enum ('SEPARACION', 'INICIAL', 'CUOTA', 'ABONO_EXTRAORDINARIO', 'AJUSTE', 'DEVOLUCION');
create type {{SCHEMA}}.forma_pago_enum as enum ('EFECTIVO', 'TRANSFERENCIA', 'YAPE', 'PLIN', 'DEPOSITO', 'TARJETA', 'OTRO');
create type {{SCHEMA}}.rol_en_venta_enum as enum ('TITULAR', 'CONYUGE', 'CONVIVIENTE', 'COTITULAR', 'GARANTE', 'FAMILIAR', 'OTRO');
create type {{SCHEMA}}.accion_admin_enum as enum (
  'AGREGAR_VINCULACION_VENTA_PERSONA',
  'QUITAR_VINCULACION_VENTA_PERSONA',
  'LIBERAR_LOTE',
  'ANULAR_VENTA',
  'EDITAR_PAGO',
  'REASIGNAR_VENTA'
);

-- ------------------------------------------------------------
-- Master tables
-- ------------------------------------------------------------
create table {{SCHEMA}}.personas (
  id uuid primary key default gen_random_uuid(),
  tipo_documento {{SCHEMA}}.tipo_documento_enum not null default 'DNI',
  numero_documento text not null,
  nombres text not null,
  apellidos text not null,
  fecha_nacimiento date,
  celular text,
  correo text,
  ocupacion text,
  direccion text,
  departamento text,
  provincia text,
  distrito text,
  referencia text,
  estado {{SCHEMA}}.estado_general_enum not null default 'ACTIVO',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint personas_numero_documento_not_blank check (btrim(numero_documento) <> '')
);

create table {{SCHEMA}}.usuarios (
  id uuid primary key default gen_random_uuid(),
  persona_id uuid not null references {{SCHEMA}}.personas(id),
  username text not null,
  pin_hash text not null,
  rol {{SCHEMA}}.rol_usuario_enum not null,
  estado {{SCHEMA}}.estado_general_enum not null default 'ACTIVO',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint usuarios_username_not_blank check (btrim(username) <> ''),
  constraint usuarios_pin_hash_not_blank check (btrim(pin_hash) <> '')
);

create table {{SCHEMA}}.empresas (
  id uuid primary key default gen_random_uuid(),
  razon_social text not null,
  nombre_comercial text,
  ruc text not null,
  telefono text,
  correo text,
  direccion text,
  estado {{SCHEMA}}.estado_general_enum not null default 'ACTIVO',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint empresas_ruc_not_blank check (btrim(ruc) <> '')
);

create table {{SCHEMA}}.proyectos (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references {{SCHEMA}}.empresas(id),
  nombre text not null,
  codigo text not null,
  descripcion text,
  departamento text,
  provincia text,
  distrito text,
  sector text,
  direccion_referencia text,
  estado {{SCHEMA}}.estado_general_enum not null default 'ACTIVO',
  fecha_inicio_comercial date,
  fecha_fin_comercial date,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint proyectos_codigo_not_blank check (btrim(codigo) <> '')
);

create table {{SCHEMA}}.lotes (
  id uuid primary key default gen_random_uuid(),
  proyecto_id uuid not null references {{SCHEMA}}.proyectos(id),
  codigo text not null,
  manzana text not null,
  numero integer not null,
  area_m2 numeric(10,2),
  precio_lista numeric(12,2) not null default 0,
  precio_minimo numeric(12,2),
  precio_referencial numeric(12,2),
  estado_comercial {{SCHEMA}}.estado_lote_enum not null default 'LIBRE',
  moneda text not null default 'PEN',
  observaciones text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint lotes_codigo_not_blank check (btrim(codigo) <> ''),
  constraint lotes_manzana_not_blank check (btrim(manzana) <> ''),
  constraint lotes_numero_positive check (numero > 0),
  constraint lotes_area_non_negative check (area_m2 is null or area_m2 >= 0),
  constraint lotes_precio_lista_non_negative check (precio_lista >= 0),
  constraint lotes_precio_minimo_non_negative check (precio_minimo is null or precio_minimo >= 0),
  constraint lotes_precio_referencial_non_negative check (precio_referencial is null or precio_referencial >= 0)
);

-- ------------------------------------------------------------
-- Transactional tables
-- ------------------------------------------------------------
create table {{SCHEMA}}.ventas (
  id uuid primary key default gen_random_uuid(),
  proyecto_id uuid not null references {{SCHEMA}}.proyectos(id),
  lote_id uuid not null references {{SCHEMA}}.lotes(id),
  cliente_titular_persona_id uuid not null references {{SCHEMA}}.personas(id),
  asesor_usuario_id uuid not null references {{SCHEMA}}.usuarios(id),
  codigo_venta text not null,
  etapa_venta {{SCHEMA}}.etapa_venta_enum not null default 'SEPARADO',
  estado_registro {{SCHEMA}}.estado_registro_enum not null default 'ACTIVO',
  fecha_venta date not null default current_date,
  fecha_separacion date,
  fecha_contrato date,
  precio_lote numeric(12,2) not null default 0,
  monto_separacion_pactado numeric(12,2) not null default 0,
  monto_inicial_pactado numeric(12,2) not null default 0,
  monto_financiado_pactado numeric(12,2) not null default 0,
  numero_cuotas_pactadas integer not null default 0,
  monto_cuota_referencial numeric(12,2) not null default 0,
  plazo_meses integer not null default 0,
  pagado_total numeric(12,2) not null default 0,
  saldo_pendiente numeric(12,2) not null default 0,
  moneda text not null default 'PEN',
  observaciones text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint ventas_codigo_venta_not_blank check (btrim(codigo_venta) <> ''),
  constraint ventas_precio_lote_non_negative check (precio_lote >= 0),
  constraint ventas_monto_separacion_non_negative check (monto_separacion_pactado >= 0),
  constraint ventas_monto_inicial_non_negative check (monto_inicial_pactado >= 0),
  constraint ventas_monto_financiado_non_negative check (monto_financiado_pactado >= 0),
  constraint ventas_numero_cuotas_non_negative check (numero_cuotas_pactadas >= 0),
  constraint ventas_monto_cuota_non_negative check (monto_cuota_referencial >= 0),
  constraint ventas_plazo_meses_non_negative check (plazo_meses >= 0),
  constraint ventas_pagado_total_non_negative check (pagado_total >= 0),
  constraint ventas_saldo_pendiente_non_negative check (saldo_pendiente >= 0)
);

create table {{SCHEMA}}.ventas_clientes (
  id uuid primary key default gen_random_uuid(),
  venta_id uuid not null references {{SCHEMA}}.ventas(id) on delete cascade,
  persona_id uuid not null references {{SCHEMA}}.personas(id),
  rol_en_venta {{SCHEMA}}.rol_en_venta_enum not null,
  es_titular boolean not null default false,
  observacion text,
  agregado_por_usuario_id uuid not null references {{SCHEMA}}.usuarios(id),
  autorizado_por_usuario_id uuid references {{SCHEMA}}.usuarios(id),
  fecha_autorizacion timestamptz,
  motivo_autorizacion text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint ventas_clientes_titular_consistente check (
    (es_titular = true and rol_en_venta = 'TITULAR')
    or (es_titular = false)
  ),
  constraint ventas_clientes_autorizacion_consistente check (
    (autorizado_por_usuario_id is null and fecha_autorizacion is null and motivo_autorizacion is null)
    or
    (autorizado_por_usuario_id is not null and fecha_autorizacion is not null and btrim(coalesce(motivo_autorizacion, '')) <> '')
  )
);

create table {{SCHEMA}}.pagos (
  id uuid primary key default gen_random_uuid(),
  venta_id uuid not null references {{SCHEMA}}.ventas(id) on delete cascade,
  tipo_pago {{SCHEMA}}.tipo_pago_enum not null,
  concepto text,
  fecha_pago date not null default current_date,
  monto numeric(12,2) not null,
  forma_pago {{SCHEMA}}.forma_pago_enum not null,
  numero_operacion text,
  moneda text not null default 'PEN',
  observaciones text,
  registrado_por_usuario_id uuid not null references {{SCHEMA}}.usuarios(id),
  estado_registro {{SCHEMA}}.estado_registro_enum not null default 'ACTIVO',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint pagos_monto_non_negative check (monto >= 0)
);

create table {{SCHEMA}}.autorizaciones_admin (
  id uuid primary key default gen_random_uuid(),
  usuario_admin_id uuid not null references {{SCHEMA}}.usuarios(id),
  usuario_solicitante_id uuid not null references {{SCHEMA}}.usuarios(id),
  accion {{SCHEMA}}.accion_admin_enum not null,
  tabla_objetivo text not null,
  registro_objetivo_id uuid,
  motivo text not null,
  fecha_autorizacion timestamptz not null default now(),
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint autorizaciones_admin_tabla_not_blank check (btrim(tabla_objetivo) <> ''),
  constraint autorizaciones_admin_motivo_not_blank check (btrim(motivo) <> '')
);

-- ------------------------------------------------------------
-- Indexes and unique constraints
-- ------------------------------------------------------------
create unique index personas_tipo_numero_unique_idx
  on {{SCHEMA}}.personas (tipo_documento, numero_documento);
create index personas_numero_documento_idx
  on {{SCHEMA}}.personas (numero_documento);

create unique index usuarios_username_unique_idx
  on {{SCHEMA}}.usuarios (lower(username));
create unique index usuarios_persona_unique_idx
  on {{SCHEMA}}.usuarios (persona_id);
create index usuarios_rol_estado_idx
  on {{SCHEMA}}.usuarios (rol, estado);

create unique index empresas_ruc_unique_idx
  on {{SCHEMA}}.empresas (ruc);

create index proyectos_empresa_id_idx
  on {{SCHEMA}}.proyectos (empresa_id);
create unique index proyectos_empresa_codigo_unique_idx
  on {{SCHEMA}}.proyectos (empresa_id, codigo);

create index lotes_proyecto_id_idx
  on {{SCHEMA}}.lotes (proyecto_id);
create unique index lotes_proyecto_codigo_unique_idx
  on {{SCHEMA}}.lotes (proyecto_id, codigo);
create unique index lotes_proyecto_manzana_numero_unique_idx
  on {{SCHEMA}}.lotes (proyecto_id, manzana, numero);
create index lotes_estado_comercial_idx
  on {{SCHEMA}}.lotes (estado_comercial);

create unique index ventas_codigo_venta_unique_idx
  on {{SCHEMA}}.ventas (codigo_venta);
create index ventas_lote_id_idx
  on {{SCHEMA}}.ventas (lote_id);
create index ventas_cliente_titular_idx
  on {{SCHEMA}}.ventas (cliente_titular_persona_id);
create index ventas_asesor_usuario_idx
  on {{SCHEMA}}.ventas (asesor_usuario_id);
create index ventas_etapa_idx
  on {{SCHEMA}}.ventas (etapa_venta);

-- Rule: a lot cannot have more than one active sale in active stages.
create unique index ventas_lote_unica_activa_idx
  on {{SCHEMA}}.ventas (lote_id)
  where estado_registro = 'ACTIVO'
    and etapa_venta in ('SEPARADO', 'CONTRATO', 'PAGANDO');

create index ventas_clientes_venta_id_idx
  on {{SCHEMA}}.ventas_clientes (venta_id);
create index ventas_clientes_persona_id_idx
  on {{SCHEMA}}.ventas_clientes (persona_id);
create unique index ventas_clientes_unique_idx
  on {{SCHEMA}}.ventas_clientes (venta_id, persona_id, rol_en_venta);

create index pagos_venta_id_idx
  on {{SCHEMA}}.pagos (venta_id);
create index pagos_fecha_pago_idx
  on {{SCHEMA}}.pagos (fecha_pago);
create index pagos_tipo_pago_idx
  on {{SCHEMA}}.pagos (tipo_pago);

create index autorizaciones_admin_admin_idx
  on {{SCHEMA}}.autorizaciones_admin (usuario_admin_id);
create index autorizaciones_admin_solicitante_idx
  on {{SCHEMA}}.autorizaciones_admin (usuario_solicitante_id);
create index autorizaciones_admin_fecha_idx
  on {{SCHEMA}}.autorizaciones_admin (fecha_autorizacion);

-- ------------------------------------------------------------
-- Functions and triggers
-- ------------------------------------------------------------
create or replace function {{SCHEMA}}.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create or replace function {{SCHEMA}}.trg_ventas_set_financial_snapshot()
returns trigger
language plpgsql
as $$
begin
  new.precio_lote := coalesce(new.precio_lote, 0);
  new.monto_separacion_pactado := coalesce(new.monto_separacion_pactado, 0);
  new.monto_inicial_pactado := coalesce(new.monto_inicial_pactado, 0);
  new.monto_financiado_pactado := coalesce(new.monto_financiado_pactado, 0);
  new.numero_cuotas_pactadas := coalesce(new.numero_cuotas_pactadas, 0);
  new.monto_cuota_referencial := coalesce(new.monto_cuota_referencial, 0);
  new.plazo_meses := coalesce(new.plazo_meses, 0);
  new.pagado_total := coalesce(new.pagado_total, 0);
  new.saldo_pendiente := greatest(new.precio_lote - new.pagado_total, 0);
  return new;
end;
$$;

create or replace function {{SCHEMA}}.recalculate_venta_totales(p_venta_id uuid)
returns void
language plpgsql
as $$
declare
  v_pagado_total numeric(12,2);
begin
  if p_venta_id is null then
    return;
  end if;

  select coalesce(sum(
    case
      when p.estado_registro <> 'ACTIVO' then 0
      when p.tipo_pago = 'DEVOLUCION' then -p.monto
      else p.monto
    end
  ), 0)::numeric(12,2)
  into v_pagado_total
  from {{SCHEMA}}.pagos p
  where p.venta_id = p_venta_id;

  update {{SCHEMA}}.ventas v
  set pagado_total = greatest(v_pagado_total, 0),
      saldo_pendiente = greatest(coalesce(v.precio_lote, 0) - greatest(v_pagado_total, 0), 0),
      updated_at = now()
  where v.id = p_venta_id;
end;
$$;

create or replace function {{SCHEMA}}.trg_pagos_recalculate_venta_totales()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'DELETE' then
    perform {{SCHEMA}}.recalculate_venta_totales(old.venta_id);
    return old;
  end if;

  perform {{SCHEMA}}.recalculate_venta_totales(new.venta_id);

  if tg_op = 'UPDATE' and old.venta_id is distinct from new.venta_id then
    perform {{SCHEMA}}.recalculate_venta_totales(old.venta_id);
  end if;

  return new;
end;
$$;

create or replace function {{SCHEMA}}.refresh_lote_estado_comercial(p_lote_id uuid)
returns void
language plpgsql
as $$
declare
  v_estado {{SCHEMA}}.estado_lote_enum := 'LIBRE';
begin
  if p_lote_id is null then
    return;
  end if;

  if exists (
    select 1
    from {{SCHEMA}}.ventas v
    where v.lote_id = p_lote_id
      and v.estado_registro = 'ACTIVO'
      and v.etapa_venta = 'COMPLETADO'
  ) then
    v_estado := 'VENDIDO';
  elsif exists (
    select 1
    from {{SCHEMA}}.ventas v
    where v.lote_id = p_lote_id
      and v.estado_registro = 'ACTIVO'
      and v.etapa_venta in ('SEPARADO', 'CONTRATO', 'PAGANDO')
  ) then
    v_estado := 'SEPARADO';
  else
    v_estado := 'LIBRE';
  end if;

  update {{SCHEMA}}.lotes
  set estado_comercial = v_estado,
      updated_at = now()
  where id = p_lote_id;
end;
$$;

create or replace function {{SCHEMA}}.trg_ventas_sync_business_rules()
returns trigger
language plpgsql
as $$
begin
  if tg_op = 'DELETE' then
    perform {{SCHEMA}}.refresh_lote_estado_comercial(old.lote_id);
    return old;
  end if;

  perform {{SCHEMA}}.recalculate_venta_totales(new.id);

  if tg_op = 'UPDATE' and old.lote_id is distinct from new.lote_id then
    perform {{SCHEMA}}.refresh_lote_estado_comercial(old.lote_id);
  end if;

  perform {{SCHEMA}}.refresh_lote_estado_comercial(new.lote_id);
  return new;
end;
$$;

create or replace function {{SCHEMA}}.trg_ventas_insert_titular()
returns trigger
language plpgsql
as $$
begin
  insert into {{SCHEMA}}.ventas_clientes (
    venta_id,
    persona_id,
    rol_en_venta,
    es_titular,
    agregado_por_usuario_id
  )
  values (
    new.id,
    new.cliente_titular_persona_id,
    'TITULAR',
    true,
    new.asesor_usuario_id
  )
  on conflict (venta_id, persona_id, rol_en_venta)
  do update set
    es_titular = excluded.es_titular,
    updated_at = now();

  return new;
end;
$$;

-- updated_at triggers
create trigger trg_personas_updated_at
before update on {{SCHEMA}}.personas
for each row execute procedure {{SCHEMA}}.set_updated_at();

create trigger trg_usuarios_updated_at
before update on {{SCHEMA}}.usuarios
for each row execute procedure {{SCHEMA}}.set_updated_at();

create trigger trg_empresas_updated_at
before update on {{SCHEMA}}.empresas
for each row execute procedure {{SCHEMA}}.set_updated_at();

create trigger trg_proyectos_updated_at
before update on {{SCHEMA}}.proyectos
for each row execute procedure {{SCHEMA}}.set_updated_at();

create trigger trg_lotes_updated_at
before update on {{SCHEMA}}.lotes
for each row execute procedure {{SCHEMA}}.set_updated_at();

create trigger trg_ventas_updated_at
before update on {{SCHEMA}}.ventas
for each row execute procedure {{SCHEMA}}.set_updated_at();

create trigger trg_ventas_clientes_updated_at
before update on {{SCHEMA}}.ventas_clientes
for each row execute procedure {{SCHEMA}}.set_updated_at();

create trigger trg_pagos_updated_at
before update on {{SCHEMA}}.pagos
for each row execute procedure {{SCHEMA}}.set_updated_at();

create trigger trg_autorizaciones_admin_updated_at
before update on {{SCHEMA}}.autorizaciones_admin
for each row execute procedure {{SCHEMA}}.set_updated_at();

-- Financial and business-rule triggers
create trigger trg_ventas_set_financial_snapshot
before insert or update on {{SCHEMA}}.ventas
for each row execute procedure {{SCHEMA}}.trg_ventas_set_financial_snapshot();

create trigger trg_ventas_insert_titular
after insert on {{SCHEMA}}.ventas
for each row execute procedure {{SCHEMA}}.trg_ventas_insert_titular();

create trigger trg_ventas_sync_business_rules
after insert or update or delete on {{SCHEMA}}.ventas
for each row execute procedure {{SCHEMA}}.trg_ventas_sync_business_rules();

create trigger trg_pagos_recalculate_venta_totales
after insert or update or delete on {{SCHEMA}}.pagos
for each row execute procedure {{SCHEMA}}.trg_pagos_recalculate_venta_totales();
